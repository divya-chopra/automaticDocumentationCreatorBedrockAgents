exports.handler = async (event) => {
    try {
        // Parse the incoming request body
        const body = event.body ? JSON.parse(event.body) : {};
        
        // Get name from request or use default
        const name = body.name || "World";
        
        // Create response
        const response = {
            message: `Hello,`,
            timestamp: new Date().toISOString(),
            requestDetails: {
                method: event.httpMethod,
                path: event.path,
                queryStringParameters: event.queryStringParameters
            }
        };
        
        // Return successful response
        return {
            statusCode: 200,
            headers: {
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "*"
            },
            body: JSON.stringify(response)
        };
    } catch (error) {
        // Return error response if something goes wrong
        return {
            statusCode: 500,
            headers: {
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "*"
            },
            body: JSON.stringify({
                message: "Error processing request",
                error: error.message
            })
        };
    }
};
